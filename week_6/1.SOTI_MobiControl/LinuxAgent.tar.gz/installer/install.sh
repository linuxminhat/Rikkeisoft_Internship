#!/bin/sh

# MobiControl Agent for Linux Installer Version 2.7
#
#==============================================================================
# Usage: install.sh [OPTIONS]
#	  -c
#	    Clean install. Will remove existing agent and configuration before 
#		installing. Will require confirmation if not used with -y. 
#	  -h
#	    Help. Prints this message and exits.
#	  -y
#	    Automatically accepts all prompts. Use at your own risk.
#	  -v
#		Verbose Mode.
#	  -p
#		Select agent platfome: (list is in PLATFORM_LIST array)
#	  -n
#		No Install. Will not start installation, only download required files.
#==============================================================================
# This script must be run with root permission to function properly. systemd,
# upstart, sysvinit, and busybox init are supported.
# 
SCRIPT_VERSION=2.7
DEBUG_OUTPUT=true #False by default
CLEAN_INSTALL= #False by default
AUTOACCEPT_PROMPTS= #False by default
NO_INSTALL= #False by default
USE_CURL=true #True by default
XTHUB_AGENT= #Set by CMake
XTHUB_ENROLLMENT_OVERRIDE="DEVICE_IS_XTHUB"
SYSTEM_DOTNET= #False by default

AGENT_FILE="mobicontrol"
CONFIG_FILE="MCSetup.ini"
INSTALL_DIR="/usr/opt/MobiControl"
INITSYSTEM=
INITD_FILE="sysv/mobicontrol"
SYSTEMD_FILE="systemd/mobicontrol.service"
UPSTART_FILE="upstart/mobicontrol.conf"
COMM_STATUS_DIR="/tmp/mobicontrol_status"
PLATFORM_DISPLAY=
USER_DEFINED_PLATFORM=${AGENT_PLATFORM}
TAR_FILE_NAME="installer.tar.gz"
TAR_FILE_LINK="TAR_FILE_URL"
INI_FILE_LINK="INI_FILE_URL"
TARFILEEXISTENCE=
PLATFORM_LIST="ARM ARM_Headless \
ARM64 ARM64_Headless \
ARM_SF ARM_SF_Headless \
x86 x86_Headless \
x64 x64_Headless"
XTHUB_PLATFORMS="ARM ARM_Headless
ARM64 ARM64_Headless
x64 x64_Headless"

# Read secret string
read_secret()
{
    # Disable echo.
    stty -echo

    # Set up trap to ensure echo is enabled before exiting if the script
    # is terminated while echo is disabled.
    trap 'stty echo' EXIT

    # Read secret.
    read "$@"

    # Enable echo.
    stty echo
    trap - EXIT

    # Print a newline because the newline entered by the user after
    # entering the passcode is not echoed. This ensures that the
    # next line of output begins at a new line.
    echo
}

#Test connection to server
pass() {
	echo "MobiControl agent was successfully installed"
	pipe=/tmp/pipo
	stdinput=/dev/stdin
	rm $pipe 2>/dev/null
	if [ ! -p $pipe ]; then
	    mkfifo $pipe
	fi

	while true
	do
	   if read -r line <$pipe; then
	       if [ "$line" = "quitAgent" ]; then
		    killRunningAgent
		    rm -rf /tmp/mobicontrol_status
		    break
	       fi
	       if [ "$line" = "IP_NOT_FOUND" ]; then
	       	break
	       fi
	       if [ "$line" = "quit" ]; then
	       	break
	       fi

	       strippedLine=$(echo $line | sed 's/[t ]*$//g')
	       if [ "$strippedLine" = "Please enter agent enrollment password:" ] || [ "$strippedLine" = "Please enter LDAP password:" ]; then
	       	printf "$strippedLine "
	       	if read_secret line2 <$stdinput; then
	       		oldIFS="$IFS"; IFS="";
	       		echo $line2 >$pipe
	       		echo $pipe >/dev/null
	       		IFS="$oldIFS"
	       	fi
	       	continue
	       elif [ "$strippedLine" = "Please enter LDAP username:" ]; then
	       	printf "$strippedLine "
	       	if read line2 <$stdinput; then
	       		oldIFS="$IFS"; IFS="";
	       		echo $line2 >$pipe
	       		echo $pipe >/dev/null
	       		IFS="$oldIFS"
	       	fi
	       	continue
	       elif [ "$line" = "Please enter agent enrollment password" ]; then
	       	echo $line
	       	if read line2 <$stdinput; then
	       		oldIFS="$IFS"; IFS="";
	       		echo $line2 >$pipe
	       		echo $pipe >/dev/null
	       		IFS="$oldIFS"
	       	fi
	       	continue
	       fi
		   
		   echo $line
	   fi
	  
	done
	rm /tmp/pipo 2> /dev/null
	if [ "$line" != "quitAgent" ]; then
    	echo "Connecting to MobiControl Server..."
	fi
	connected=
	for i in 1 2 3 4 5; do		
		if getNetworkCommand; then
			connected=true
			break
		fi
		sleep 5
	done

	if [ $connected ]; then
		echo "Agent is connected to MobiControl server"
    else
		echo "Agent is not connected to MobiControl server
                       ***Please check your internet connection as well as deployment server address. Use ./mobicontrol -s command to check the Mobicontrol agent connection status***"
    fi

	cleanInstaller
	exit 0
}

fail() {
	cleanInstaller
	>&2 echo "MobiControl agent installation failed. Exiting."
	exit 1
}

getPlatform() {
	#if platform is already set by environment variable or cli option then 
	#skip detection.
	if [ ${USER_DEFINED_PLATFORM} ]; then
		PLATFORM_DISPLAY=${USER_DEFINED_PLATFORM}
		[ "$DEBUG_OUTPUT" ] && echo "User defined agent type is $PLATFORM_DISPLAY"
		return
	fi

	PLATFORM=$(uname -m)
	case $PLATFORM in
		x86_64)AGENT_PLATFORM="x64";;
		i686)AGENT_PLATFORM="x86";;
		armv7l)AGENT_PLATFORM="ARM";;
		aarch64 | aarch64_be)AGENT_PLATFORM="ARM64";;
		arm64 | armv8b | armv8l)AGENT_PLATFORM="ARM64";;
		
		*)
			>&2 echo "Unrecognized architecture $PLATFORM."
			fail
			;;
	esac
	[ "$DEBUG_OUTPUT" ] && echo "Detected architechture is $AGENT_PLATFORM"
		
	if ! command -v X >/dev/null 2>&1; then
		AGENT_DISPLAY="Headless"
		[ "$DEBUG_OUTPUT" ] && echo "System detected as Headless"
	else
		AGENT_DISPLAY="Headed"
		[ "$DEBUG_OUTPUT" ] && echo "System detected as Headful"
	fi

	PLATFORM_DISPLAY="Linux_$AGENT_PLATFORM"
	if [ $AGENT_DISPLAY  = "Headless" ]; then
		PLATFORM_DISPLAY="${PLATFORM_DISPLAY}_Headless"
	fi
	if [ $XTHUB_AGENT ]; then
		PLATFORM_DISPLAY="${PLATFORM_DISPLAY}_XTremeHub"
	fi

	[ "$DEBUG_OUTPUT" ] && echo "Agent type is $PLATFORM_DISPLAY"
}

# Check for a file and if it is missing try to download it. 
# syntax:
# getFile fileName downloadLink validateCert
# examples:
# getFile $CONFIG_FILE $INI_FILE_LINK
# getFile $CONFIG_FILE $INI_FILE_LINK true
# getFile $TAR_FILE_NAME $TAR_FILE_LINK$PLATFORM_DISPLAY
getFile() {
	[ "$DEBUG_OUTPUT" ] && echo "Checking for $1 in current directory"
	if [ ! -f "$1" ]; then
		[ "$DEBUG_OUTPUT" ] && echo "$1 not found in current directory. Attempting to fetch from server."
		CERT_CHECK="--no-check-certificate"
		[ "$3" ] && CERT_CHECK="--secure-protocol=auto"
		#Download File
		if [ "$USE_CURL" = true ];then
			curl --insecure -o "$1" "$2" >/dev/null 2>&1
		else
			wget --no-check-certificate -O "$1" "$2" >/dev/null 2>&1
		fi

		if [ $? != 0 ]; then
			rm -f "$1"
			echo "Error when downloading $1 from server.. http client error"
			return 1
		elif [ ! -s "$1" ]; then
			rm -f "$1"
			echo "Error when downloading $1 from server..file is empty"
			return 1
		else
			[ "$DEBUG_OUTPUT" ] && echo "$1 downloaded successfully."
			return 0
		fi
	else
		[ "$DEBUG_OUTPUT" ] && echo "$1 found in current directory"
		return 0
	fi
}

#Remove untarred installer directory.
cleanInstaller() {
	rm -r installer >/dev/null 2>&1
}

#Use socket checking command as available on the system
getNetworkCommand () {
	if command -v ss >/dev/null; then
		ss -ptn state connected | grep "mobicontrol" >/dev/null
		return $?
	elif command -v lsof >/dev/null; then
		lsof -i -Fc | grep cmobicontrol >/dev/null #cmobicontrol isn't a typo, lsof prepends it to specify it as a "command name"
		return $?
	elif command -v netstat >/dev/null; then
		netstat -ptn | grep ESTABLISHED.*/mobicontrol >/dev/null
		return $?
	else
		>&2 echo "No compatible network command found. Unable to check connection."
		return 0
	fi
}
#Remove current agent and config file.
fullClean() {
	killRunningAgent
	[ "$DEBUG_OUTPUT" ] && echo "Removing installed agent and settings..."
	rm $INSTALL_DIR/$AGENT_FILE >/dev/null 2>&1
	rm $INSTALL_DIR/pdb.ini >/dev/null 2>&1
	rm $INSTALL_DIR/pdbt.ini >/dev/null 2>&1
	rm $INSTALL_DIR/pdbBackup.ini >/dev/null 2>&1
	cleanInstaller
}

killRunningAgent() {
	[ "$DEBUG_OUTPUT" ] && echo "Killing running agent..."
	systemctl stop mobicontrol >/dev/null 2>&1 || initctl stop mobicontrol >/dev/null 2>&1 || /etc/init.d/mobicontrol stop >/dev/null 2>&1
}

#Print usage message and exit.
getHelp() {
	printf "Usage: install.sh [OPTIONS] [-p <platform>]\n-c\n  Clean install. Will remove existing agent and configuration before installing.\n  Will require confirmation if not used with -y."
	printf "\n-v\n  Verbose output."
	printf "\n-h\n  Help. Prints this message and exits.\n-y\n  Automatically accepts all prompts. Use at your own risk."
	printf "\n-p\n  Agent platform to install, examples of supported platforms:\n  %s""$PLATFORM_LIST"
	printf "\n-n\n  No Install. Will not start installation, only download required files."
	printf "\n-x\n  Install agent as an XTremeHub agent. See https://www.soti.net/mc/help/v15.4/en/console/data/xtremehubs/xtreme_hubs.html for more information."
	printf "\n"
	exit 1
}

#Read user input. True if y or Y is pressed (or -y option is set), false otherwise. 

getUserResponse() {
	if [ "$AUTOACCEPT_PROMPTS" ]; then
		return 0
	fi
	read -r userResponse
	case $userResponse in
		[yY])
			return 0;;
		*)
			return 1;;
	esac
}

#returns 0 for true and 1 for false.
isKnownPlatform() {
	for p in $XTHUB_PLATFORMS; do
		[ "$p" = "$1" ] && return 0
	done
	return 1
}

isXTHubPlatform() {
	for p in $PLATFORM_LIST; do
		[ "$p" = "$1" ] && return 0
	done
	return 1
}

installLocalDotNet() {
	[ $1 ] && INSTALL_DIR=$1
	DOTNET_URL=
	DOTNET_CHECKSUM=
	ASPNET_URL=
	ASPNET_CHECKSUM=
	#.NET 6 only provides Linux binaries for x64, ARM, and ARM64
	if [ $AGENT_PLATFORM = "ARM" -o $AGENT_PLATFORM = "ARM_Headless" ]; then
		DOTNET_URL="https://download.visualstudio.microsoft.com/download/pr/bdea32df-7ab8-47f5-8f8c-3de28d5771d0/c839293beeace695b6698debaedd345e/dotnet-runtime-6.0.1-linux-arm.tar.gz"
		DOTNET_CHECKSUM="a6bea3289279ddfaeda4c46bc2cae82c662e2b2cfa13abefa18baa8db747bd1be9fabdd8c0103310f89d4c9e356235551af5354742117d2cd58abf5727883609"
		ASPNET_URL="https://download.visualstudio.microsoft.com/download/pr/ff3b2714-0dee-4cf9-94ee-cb9f5ded285f/d6bfe8668428f9eb28acdf6b6f5a81bc/aspnetcore-runtime-6.0.1-linux-arm.tar.gz"
		ASPNET_CHECKSUM="e1d9f0b2357ba637ee33bc8f8428b9ff0b3656ac28d1f7727693444191cc8a0a078c2e864547d58668cf3767f0b6df5b804e2743b6fb0906106d2877cdb687dc"
	elif [ $AGENT_PLATFORM = "ARM64" -o $AGENT_PLATFORM = "ARM64_Headless" ]; then
		DOTNET_URL="https://download.visualstudio.microsoft.com/download/pr/002742a9-8107-4434-a208-863f07e09397/75884224d828a34b7c5f070df5213553/dotnet-runtime-6.0.1-linux-arm64.tar.gz"
		DOTNET_CHECKSUM="10b8775d44088ddc1ae193ce41f456d1bbaad21f2dc993de75c2b076b6ffcb07bca446f52180c9a175715a1e47ad42a4862c43ef11b5cbc1023cb4da3c426146"
		ASPNET_URL="https://download.visualstudio.microsoft.com/download/pr/01f8a4af-9d6c-40ff-b834-a1d73105a9d5/aba0525a8b8cb745ac70ecd671acf0e0/aspnetcore-runtime-6.0.1-linux-arm64.tar.gz"
		ASPNET_CHECKSUM="c1cab4bc800bd507ca6046ed1af900a7f1a7d28fa564615b8b93803139affc7f5fe6824c2b161ce635047862d644d724181424b44281b30a77f7159d6769c83c"
	elif [ $AGENT_PLATFORM = "x64" -o $AGENT_PLATFORM = "x64_Headless" ]; then
		DOTNET_URL="https://download.visualstudio.microsoft.com/download/pr/be8a513c-f3bb-4fbd-b382-6596cf0d67b5/968e205c44eabd205b8ea98be250b880/dotnet-runtime-6.0.1-linux-x64.tar.gz"
		DOTNET_CHECKSUM="2a316e8cba20778b409b8f2a3810348e2805f35afad8aba77a67c4e6bb2c2091e60bc369df22554bb145a5fad0c50e20b39d350b98a85bd33566034a11230da7"
		ASPNET_URL="https://download.visualstudio.microsoft.com/download/pr/32230fb9-df1e-4b86-b009-12d889cbfa8a/f57a5d92327bb2936caac94bcf602c22/aspnetcore-runtime-6.0.1-linux-x64.tar.gz"
		ASPNET_CHECKSUM="9e42c4ac282d3ed099203b9a8a06b4f1baf1267b4d51c9d505ca7127930534b60d4e94022036719133b30c1b503f66d7d4571bc24059d735e510f5e455ec6c51"
	fi

	#Download runtime archive files
	DOTNET_FILENAME=$(echo "$DOTNET_URL" | awk -F/ '{print $NF}')
	ASPNET_FILENAME=$(echo "$ASPNET_URL" | awk -F/ '{print $NF}')
	if ! getFile "$DOTNET_FILENAME" "$DOTNET_URL" "true"; then
		echo "Error downloading .NET runtime from $DOTNET_URL. Aborting."
		fail
	fi
	if ! getFile "$ASPNET_FILENAME" "$ASPNET_URL" "true"; then
		echo "Error downloading ASP.NET runtime from $ASPNET_URL. Aborting."
		fail
	fi

	#Verify checksums against downloaded archives
	if command -v sha512sum >/dev/null 2>&1; then
		DOTNET_DOWNLOADED_CHECKSUM=$(sha512sum $DOTNET_FILENAME | awk -F' ' '{print $1}')
		ASPNET_DOWNLOADED_CHECKSUM=$(sha512sum $ASPNET_FILENAME | awk -F' ' '{print $1}')
		if [ $DOTNET_DOWNLOADED_CHECKSUM != $DOTNET_CHECKSUM ]; then
			echo "Checksum for $DOTNET_FILENAME is a mismatch. Expected: $DOTNET_CHECKSUM Downloaded: $DOTNET_DOWNLOADED_CHECKSUM Aborting."
			fail
		elif [ $ASPNET_DOWNLOADED_CHECKSUM != $ASPNET_CHECKSUM ]; then
			echo "Checksum for $ASPNET_FILENAME is a mismatch. Expected: $ASPNET_CHECKSUM Downloaded: $ASPNET_DOWNLOADED_CHECKSUM Aborting."
			fail
		fi
	else
		echo "WARNING! sha512sum not available. Downloaded file checksums will NOT be validated."
	fi

	#Install from archives to agent install directory
	mkdir -p $INSTALL_DIR/dotnet >/dev/null 2>&1
	if ! tar -xzf $DOTNET_FILENAME --directory $INSTALL_DIR/dotnet >/dev/null 2>&1; then
		echo "Error extracting $DOTNET_FILENAME to $INSTALL_DIR/dotnet. Aborting."
		fail
	fi
	if ! tar -xzf $ASPNET_FILENAME --directory $INSTALL_DIR/dotnet >/dev/null 2>&1; then
		echo "Error extracting $ASPNET_FILENAME to $INSTALL_DIR/dotnet. Aborting."
		fail
	fi
}

isHostnameFQDN() {
	#This is not the exact regex used by the server, but it uses PCRE, which isn't available with some (e.g. Busybox) greps
	fqdnRegex='^([a-z0-9]+(-[a-z0-9]+)*\.?)+[a-z]{2,}$'
	echo $1 | tr A-Z a-z | grep -E "$fqdnRegex" && return 0
	return 1
}

checkHostnames() {
	! command -v hostname >/dev/null 2>&1 && >&2 echo "hostname command not available. Cannot validate hostnames." && return 1
	for hostname in $(hostname 2>/dev/null) $(hostname -f 2>/dev/null) $(hostname -A 2>/dev/null); do
		isHostnameFQDN $hostname && echo "Using valid FQDN $hostname for XTremeHub." && return 0
		[ $DEBUG_OUTPUT ] && echo "Hostname $hostname is not a valid FQDN."
	done
	return 1
}

# -------------------------------------------------------------------------
# -                              MAIN                                     -
# -------------------------------------------------------------------------

#check command line parameters
while getopts cvhypxs:n option; do
	case "${option}" in
		c)CLEAN_INSTALL=true;;
		v)DEBUG_OUTPUT=true;;
		h)getHelp;;
		y)AUTOACCEPT_PROMPTS=true;;
		p)AGENT_PLATFORM=${OPTARG};;
		n)NO_INSTALL=true;;
		s)SYSTEM_DOTNET=true;;
		\?)getHelp;;
	esac
done

# Check for root
ID=$(id -u 2>/dev/null)
if [ -z "$ID" ] ;then
	ID=$(ps -o euid= -p $$ | awk '{print $1}')
fi
if [ ! $NO_INSTALL ] && [ "$ID" != "0" ]; then
	>&2 echo "This script must be run as root."
	exit 1
fi

[ $DEBUG_OUTPUT ] && echo ' ____   ___ _____ ___ '
[ $DEBUG_OUTPUT ] && echo '/ ___| / _ \_   _|_ _|'
[ $DEBUG_OUTPUT ] && echo '\___ \| | | || |  | | '
[ $DEBUG_OUTPUT ] && echo ' ___) | |_| || |  | | '
[ $DEBUG_OUTPUT ] && echo '|____/ \___/ |_| |___|'
[ $DEBUG_OUTPUT ] && echo
[ $DEBUG_OUTPUT ] && echo "MobiControl Installer Version $SCRIPT_VERSION"

isUnifiedEnrollment=true
# check if it is unified enrollment or not.
# to decide if we should attempt to download installer.tar.gz
if echo $TAR_FILE_LINK | grep '_FILE_' > /dev/null 2>&1; then
    isUnifiedEnrollment=false;
fi

#Sanity check in case XTHUB_AGENT is not set properly
if echo $XTHUB_AGENT | grep '@' > /dev/null 2>&1; then
	XTHUB_AGENT=
fi

if $isUnifiedEnrollment; then
	#During unified enrollment, server will set XTHUB_ENROLLMENT_OVERRIDE to an empty string if the device is not intended to be an XTHub. If it does not, we set XTHUB_AGENT.
	if echo $XTHUB_ENROLLMENT_OVERRIDE | grep "IS_XTHUB" >/dev/null 2>&1; then
		XTHUB_AGENT=true
	fi 
fi

mv pdb.ini MCSetup.ini >/dev/null 2>&1
[ ! -x "$(command -v curl)" ] && USE_CURL=false

if [ -e installer ]; then
	echo "A file or directory named 'installer' exists in the current directory. This file would be deleted during installation. Delete file/directory now?[Y/N]"
	if getUserResponse; then
		rm -r installer
	else
		echo "Exiting."
		exit 1
	fi
fi

if [ ! $NO_INSTALL ] && [ $CLEAN_INSTALL ]; then
	echo "Clean installation requested. The existing agent and configuration on the device will be irrevocably removed before installation. Confirm?[Y/N]"
	if getUserResponse; then
		fullClean
	else
		echo "Exiting."
		exit 1
	fi
fi

#Get architecture and headed/headless status
getPlatform

if ! $isUnifiedEnrollment; then
	#this is not unified enrollment, we skip downloading tar file
    [ $DEBUG_OUTPUT ] && printf "Not Unified enrollment, skipping installer.tar.gz download.\n"
else
	#Download tar file if its not available in current directory.
	requestParams="?platform="
	if [ ${USER_DEFINED_PLATFORM} ]; then
		requestParams="${requestParams}${USER_DEFINED_PLATFORM}"
	else
		requestParams="${requestParams}Linux_${AGENT_PLATFORM}"
		if [ $XTHUB_AGENT ]; then
			requestParams="${requestParams}_XTremeHub"
		fi
		requestParams="${requestParams}&headless="
		if [ $AGENT_DISPLAY = "Headless" ]; then
			requestParams="${requestParams}true"
		else
			requestParams="${requestParams}false"
		fi
	fi
	getFile $TAR_FILE_NAME "${TAR_FILE_LINK}${requestParams}"
fi

#Download INI file
if ! getFile $CONFIG_FILE $INI_FILE_LINK; then
	# could not find or download MCSetup.ini file
        fail
fi

#Check if installer.tar available in current folder or not
if [ -f ${TAR_FILE_NAME} ];then
	#Attempt to extract agent tgz
	if ! tar -xzf $TAR_FILE_NAME >/dev/null 2>&1; then
		>&2 echo "Could not extract from $TAR_FILE_NAME"
		fail
	fi
	TARFILEEXISTENCE=true
fi

# If NO_INSTALL is set to true, exit with status 0.
[ $NO_INSTALL ] && exit 0

#Create required directories
[ $DEBUG_OUTPUT ] && echo "Creating installation directory $INSTALL_DIR"
mkdir -p $INSTALL_DIR
if ! chmod 0700 $INSTALL_DIR; then
	>&2 echo "Could not chmod of $INSTALL_DIR." >&2
	fail
fi
[ $DEBUG_OUTPUT ] && echo "Creating COMM status directory $COMM_STATUS_DIR"
mkdir -p $COMM_STATUS_DIR
if ! chmod 0555 $COMM_STATUS_DIR; then
	>&2 echo "Could not chmod of $COMM_STATUS_DIR." >&2
	fail
fi

#Move agent and config file to installation directory
[ $DEBUG_OUTPUT ] && echo "Installing agent"
if [ -s $AGENT_FILE ]; then
	:
elif [ -s installer/$AGENT_FILE ]; then
	mv installer/$AGENT_FILE .
	mv installer/uninstall.sh .
else
	>&2 echo "Cannot find agent file."
	fail
fi

[ $DEBUG_OUTPUT ] && echo "Copying agent binary from $PWD to $INSTALL_DIR"
if ! cp $AGENT_FILE $INSTALL_DIR/$AGENT_FILE >/dev/null 2>&1; then
	>&2 echo "Error installing agent. If an agent is already installed, run again with -c to perform a clean installation."
	fail
fi
chmod 0744 $INSTALL_DIR/$AGENT_FILE

if [ $XTHUB_AGENT ]; then
	#XTHub requires a valid FQDN for the device to generate a certificate
	if ! checkHostnames; then
		>&2 echo "Cannot find a valid FQDN for the device. XTremeHub enrollment will likely fail. Continue?[Y/N]"
		[ $AUTOACCEPT_PROMPTS ] || ! getUserResponse && fail
	fi
	#If agent is installing to PWD, the files are already where they need to be
	INSTALLER_DIR="."
	if [ $TARFILEEXISTENCE ]; then
		INSTALLER_DIR="installer"
	fi
	[ $DEBUG_OUTPUT ] && echo "Copying XTremeHub library."
	if ! cp -r $INSTALLER_DIR/xthub $INSTALL_DIR; then
		>&2 echo "Error copying XTremeHub library. Aborting."
		fail
	fi
	if [ ! $SYSTEM_DOTNET ]; then
		installLocalDotNet $INSTALL_DIR
	else
		[ $DEBUG_OUTPUT ] && echo "Use of system .NET specified, skipping .NET installation."
	fi
fi

[ $DEBUG_OUTPUT ] && echo "Installing config file."
if [ -s $CONFIG_FILE ]; then
	[ $DEBUG_OUTPUT ] && echo "Copying config file from $PWD to $INSTALL_DIR"
	#File has carriage returns when downloaded from server. This removes them. Printf is required since busybox sed doesnt read the escape properly.
	sed -i "s/$(printf '\r')\$//" $CONFIG_FILE
	if ! cp $CONFIG_FILE $INSTALL_DIR/pdb.ini >/dev/null 2>&1; then
		>&2 echo "Error installing config file. If an agent is already installed, run again with -c to perform a clean installation."
		fail
	fi
else
	>&2 echo "Cannot find config file."
	fail
fi
chmod 0700 $INSTALL_DIR/pdb.ini

[ $DEBUG_OUTPUT ] && echo "Detecting init system."
if [ -d /run/systemd/system ]; then
	INITSYSTEM=systemd
elif /sbin/init --version 2>/dev/null | grep "upstart"; then
	INITSYSTEM=upstart
elif [ -L /sbin/init ] && [ -d /etc/rc.d ]; then
	INITSYSTEM=busybox
elif [ -d /etc/init.d ]; then
	INITSYSTEM=sysvinit
else
	>&2 echo "Unrecognized init system."
	fail
fi
[ $DEBUG_OUTPUT ] && echo "Detected $INITSYSTEM"


case $INITSYSTEM in
	systemd)
		if [ $TARFILEEXISTENCE ]; then
			if [ ! -s installer/$SYSTEMD_FILE ]; then
				>&2 echo "systemd service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			if ! cp installer/$SYSTEMD_FILE /etc/systemd/system >/dev/null 2>&1; then
				>&2 echo "Could not copy installer/$SYSTEMD_FILE to /etc/systemd/system"
				fail
			fi
		else
			if [ ! -s $SYSTEMD_FILE ]; then
				>&2 echo "systemd service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			if ! cp $SYSTEMD_FILE /etc/systemd/system >/dev/null 2>&1; then
				>&2 echo "Could not copy $SYSTEMD_FILE to /etc/systemd/system"
				fail
			fi
		fi
		[ $DEBUG_OUTPUT ] && echo "Registering agent service."
		systemctl daemon-reload
		systemctl enable mobicontrol
		[ $DEBUG_OUTPUT ] && echo "Starting agent service."
		systemctl start mobicontrol >/dev/null 2>&1
		;;
	upstart)
		if [ $TARFILEEXISTENCE ]; then
			if [ ! -s installer/$UPSTART_FILE ]; then
				>&2 echo "upstart service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			if ! cp installer/$UPSTART_FILE /etc/init >/dev/null 2>&1; then
				>&2 echo "Could not copy installer/$UPSTART_FILE to /etc/init"
				fail
			fi
		else
			if [ ! -s $UPSTART_FILE ]; then
				>&2 echo "upstart service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			if ! cp $UPSTART_FILE /etc/init >/dev/null 2>&1; then
				>&2 echo "Could not copy $UPSTART_FILE to /etc/init"
				fail
			fi
		fi
		[ $DEBUG_OUTPUT ] && echo "Starting agent service."
		initctl start mobicontrol >/dev/null 2>&1
		;;
	busybox)
		if [ $TARFILEEXISTENCE ]; then
			if [ ! -s installer/$INITD_FILE ]; then
				>&2 echo "init.d service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			chmod 0755 installer/$INITD_FILE
			chown root:root installer/$INITD_FILE
			if ! cp installer/$INITD_FILE /etc/init.d/ >/dev/null 2>&1; then
				>&2 echo "Could not copy installer/$INITD_FILE to /etc/init.d/"
				fail
			fi
		else
			if [ ! -s $INITD_FILE ]; then
				>&2 echo "init.d service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			chmod 0755 $INITD_FILE
			chown root:root $INITD_FILE
			if ! cp $INITD_FILE /etc/init.d/ >/dev/null 2>&1; then
				>&2 echo "Could not copy $INITD_FILE to /etc/init.d/"
				fail
			fi
		fi
		[ $DEBUG_OUTPUT ] && echo "Registering agent service."
		if ! ln -fs /etc/init.d/mobicontrol /etc/rc.d/S99mobicontrol; then #no runlevels at busybox init
			>&2 echo "Could not symlink /etc/init.d/mobicontrol to /etc/rc.d/S99mobicontrol"
			fail
		fi
		[ $DEBUG_OUTPUT ] && echo "Starting agent service."
		/etc/init.d/mobicontrol start >/dev/null 2>&1
		;;
	sysvinit)
		if [ $TARFILEEXISTENCE ]; then
			if [ ! -s installer/$INITD_FILE ]; then
				>&2 echo "init.d service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			chmod 0755 installer/$INITD_FILE
			chown root:root installer/$INITD_FILE
			if ! cp installer/$INITD_FILE /etc/init.d/ >/dev/null 2>&1; then
				>&2 echo "Could not copy installer/$INITD_FILE to /etc/init.d/"
				fail
			fi
		else
			if [ ! -s $INITD_FILE ]; then
				>&2 echo "init.d service file not found."
				fail
			fi
			[ $DEBUG_OUTPUT ] && echo "Installing agent service."
			chmod 0755 $INITD_FILE
			chown root:root $INITD_FILE
			if ! cp $INITD_FILE /etc/init.d/ >/dev/null 2>&1; then
				>&2 echo "Could not copy $INITD_FILE to /etc/init.d/"
				fail
			fi
		fi
		[ $DEBUG_OUTPUT ] && echo "Registering agent service."
		if ! ln -fs /etc/init.d/mobicontrol /etc/rc3.d/S99mobicontrol; then #no runlevels at busybox init
			>&2 echo "Could not symlink /etc/init.d/mobicontrol to /etc/rc.d/S99mobicontrol"
			fail
		fi
		[ $DEBUG_OUTPUT ] && echo "Starting agent service."
		/etc/init.d/mobicontrol start >/dev/null 2>&1
		;;
esac
#Test connection to server
pass

